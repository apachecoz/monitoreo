Function Get-Suma {
param(
$Numero1, $Numero2
)

$Resultado = $Numero1 + $Numero2
Write-host $Resultado
}

Get-Suma -Numero3 8 -Numero2 12