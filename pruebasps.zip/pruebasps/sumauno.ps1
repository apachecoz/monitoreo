Function sumauno ($a)
{
	$a = $a +1
	return $a
	
}

Write-Host "Result:"
# sumauno -p 8

sumauno -a 8