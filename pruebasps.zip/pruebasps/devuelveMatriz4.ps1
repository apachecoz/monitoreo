function test () {return @('a','c'),'b'}
$a,$b = test

test