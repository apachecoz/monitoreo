$data = 'Cero','Uno','Dos','Tres'

foreach ( $node in $data )
{
    "Item: [$node]"
	"Item: $node"
}