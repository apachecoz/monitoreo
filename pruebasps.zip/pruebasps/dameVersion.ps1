function Get-Version {
    $PSVersionTable.PSVersion
}

Get-Version