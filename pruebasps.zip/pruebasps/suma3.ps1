Function Sumar ($x, $y) {
    $sumar = $x + $y
    Write-Host La respuesta es $sumar
  }

$a = 10
$b = 20
  
Sumar 3 7  

Write-Host ""
Write-Host "----------"
Write-Host ""

Sumar $a $b