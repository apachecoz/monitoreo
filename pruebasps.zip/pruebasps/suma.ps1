function Add-Numbers {
 $x = $args[0] + $args[1]
 echo $x
}

Add-Numbers 3 4